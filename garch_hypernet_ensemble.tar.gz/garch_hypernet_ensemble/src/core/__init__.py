"""Core ensemble components."""
