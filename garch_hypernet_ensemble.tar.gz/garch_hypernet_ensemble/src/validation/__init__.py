"""Data validation and cross-validation components."""
