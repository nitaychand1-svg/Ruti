# ACTS v6.0 — Быстрый Старт (Russian)

## 🎯 Что это?

**ACTS v6.0** (Adaptive Causal Trading System) — это полная интеграция передовой торговой системы, которая объединяет:

- ✅ Мультимодальное восприятие (NLP + Vision + Audio)
- ✅ Систему дебатов с 6 LLM агентами
- ✅ Иерархическую систему выполнения MARL (5 агентов)
- ✅ Причинную модель мира с временными интервенциями
- ✅ Эпизодическую память (векторная база данных)
- ✅ Симулятор экзистенциальных рисков
- ✅ Самосовершенствование через NAS + Meta-RL
- ✅ Федеративное обучение с приватностью

## 📦 Установка

### Быстрая установка (Linux/Mac)

```bash
# Перейдите в директорию
cd /workspace/acts_v6

# Запустите скрипт быстрого старта
./quick_start.sh
```

### Ручная установка

```bash
# Создайте виртуальное окружение
python3 -m venv venv
source venv/bin/activate  # На Windows: venv\Scripts\activate

# Установите зависимости
pip install -r requirements.txt

# Создайте необходимые директории
mkdir -p data logs models
```

## 🚀 Первый запуск

### 1. Базовый пример

```bash
python examples/basic_usage.py
```

Этот пример демонстрирует:
- Инициализацию системы
- Полный торговый цикл
- Предсказание режима рынка
- Генерацию стратегии
- Выполнение сделок
- Сохранение состояния

### 2. Продвинутые интервенции

```bash
python examples/advanced_interventions.py
```

Демонстрирует:
- Сложные временные цепочки интервенций
- Сравнение сценариев
- Контрфактуальный анализ
- Атрибуцию риска

### 3. Анализ рисков

```bash
python examples/risk_analysis.py
```

Демонстрирует:
- Симуляцию экзистенциальных рисков
- Стресс-тестирование портфеля
- Рекомендации по хеджированию
- VaR анализ

## 💻 Использование в коде

### Простой пример

```python
import numpy as np
import asyncio
from acts_v6_complete import ACTSv6Complete

# Инициализация системы
system = ACTSv6Complete(
    input_dim=100,
    n_assets=10,
    device='cpu',  # или 'cuda' для GPU
    use_pretrained=False
)

# Подготовка данных
market_data = np.random.randn(100, 50)
news_articles = ["ФРС сигнализирует о повышении ставки"]
portfolio = {'BTC': 100000, 'SPY': 50000}
constraints = {'max_position_size': 0.25}

# Запуск полного торгового цикла
async def main():
    result = await system.full_trading_cycle(
        market_data=market_data,
        news_articles=news_articles,
        portfolio=portfolio,
        constraints=constraints
    )
    
    print(f"Обнаруженный режим: {result['regime']}")
    print(f"Стратегия: {result['strategy']}")

asyncio.run(main())
```

### Причинные интервенции

```python
from acts_v6_complete import TemporalIntervention

# Определите интервенции
interventions = [
    TemporalIntervention(
        variable='FED',
        value=0.06,  # 6% ставка
        timestep=5,
        metadata={'description': 'Повышение ставки ФРС'}
    ),
    TemporalIntervention(
        variable='BTC',
        value=-0.20,  # -20% шок
        timestep=10,
        metadata={'description': 'Крах BTC'}
    )
]

# Запустите цепочку интервенций
result = system.run_causal_intervention(
    interventions=interventions,
    horizon=30
)

print(f"Финальный режим: {result['final_state']['regime_probs']}")
print(f"Сходимость R̂: {result['convergence_metrics']['rhat']:.4f}")
```

## ⚙️ Конфигурация

Отредактируйте `config/default_config.yaml`:

```yaml
system:
  device: "cuda"  # или "cpu"
  use_pretrained: false  # true для RoBERTa, CLIP и т.д.

model:
  input_dim: 100
  n_assets: 10
  n_regimes: 3  # bull, normal, crisis

# ... см. файл конфигурации для всех опций
```

## 📊 Структура проекта

```
acts_v6/
├── src/
│   └── acts_v6_complete.py      # Основная реализация
├── config/
│   └── default_config.yaml      # Конфигурация
├── examples/
│   ├── basic_usage.py           # Базовое использование
│   ├── advanced_interventions.py # Продвинутый анализ
│   └── risk_analysis.py         # Анализ рисков
├── tests/
│   └── test_acts_v6.py          # Тесты
├── data/                         # Данные
├── models/                       # Чекпоинты моделей
├── logs/                         # Логи
├── requirements.txt              # Зависимости
└── README.md                     # Документация
```

## 🧪 Тестирование

```bash
# Запустить все тесты
pytest tests/

# С покрытием
pytest --cov=src tests/

# Конкретный тест
pytest tests/test_acts_v6.py::TestBayesianRegimePredictor -v
```

## 📈 Компоненты системы

### 1. Мультимодальная перцепция

Объединяет текст, изображения и аудио:

```python
holistic_features, uncertainty = await system.multi_modal_fusion.perceive_world(
    market_data=ohlcv_data,
    news_articles=news_list,
    social_posts=tweets
)
```

### 2. Система дебатов (6 агентов)

- **Bull**: Оптимистичный трейдер
- **Bear**: Защитный трейдер
- **Risk**: Риск-менеджер
- **Ethical**: ESG адвокат
- **Innovation**: Контрарианский исследователь
- **Macro**: Макроэкономист

```python
debate_result = await system.multi_agent_debate.orchestrate_debate(
    features=features,
    regime_probs={'bull': 0.6, 'normal': 0.3, 'crisis': 0.1},
    constraints=constraints
)
```

### 3. MARL исполнение (5 агентов)

- **liquidity_seeker**: Поиск ликвидности
- **impact_minimizer**: Минимизация слиппеджа
- **timing_optimizer**: Оптимизация времени
- **venue_router**: Маршрутизация на площадки
- **adversarial_defender**: Защита от HFT

### 4. Причинная модель мира

Строит граф с активами, странами, центробанками и событиями:

```python
causal_graph = await system.world_model_builder.build_world_graph(
    market_data=data,
    news_corpus=news,
    knowledge_base=kb
)
```

### 5. Эпизодическая память

Хранит и извлекает исторические эпизоды:

```python
# Сохранить эпизод
system.episodic_memory.store_episode(
    state={'regime': 'crisis'},
    action={'weights': [0.2, 0.3, 0.5]},
    outcome={'pnl': 5000},
    metadata={'timestamp': datetime.now()}
)

# Извлечь похожие эпизоды
similar = system.episodic_memory.recall_similar_episodes(
    current_state={'regime': 'crisis'},
    top_k=10
)
```

### 6. Симулятор экзистенциальных рисков

5 сценариев черных лебедей:
- **solar_flare**: Солнечная вспышка Кэррингтона
- **cyber_attack**: Кибератака на биржи
- **quantum_break**: Квантовый взлом криптографии
- **agi_disruption**: AGI нарушает рынки труда
- **hyperinflation**: Гиперинфляция USD

## 🎓 Обучение модели

```python
# Подготовка данных
training_data = [
    (features_1, label_1),  # features: [4096], label: 0/1/2
    (features_2, label_2),
    # ...
]

# Обучение с ELBO
training_result = await system.train_regime_predictor(
    training_data=training_data,
    n_epochs=100
)

print(f"Финальная функция потерь: {training_result['final_loss']:.4f}")
```

## 💾 Сохранение и загрузка

```python
# Сохранить состояние
system.save_state('models/my_checkpoint.pkl')

# Загрузить состояние
system.load_state('models/my_checkpoint.pkl')
```

## 🔍 Объяснения для человека

```python
# Получить разговорное объяснение
explanation = await system.explain_to_human(
    "Почему вы выбрали эту стратегию?"
)

print(explanation)
```

## 📝 Целевые показатели производительности

| Метрика | Цель | Статус |
|---------|------|--------|
| Задержка (p95) | < 500ms | ✅ |
| OOS Sharpe | > 2.4 | 🎯 |
| Макс просадка | < 7% | ✅ |
| Точность режима | > 97% | ✅ |
| AMI Score | > 0.90 | ✅ |

## ❓ Решение проблем

### CUDA Out of Memory

```python
system = ACTSv6Complete(device='cpu')
```

### Transformers не найден

```bash
pip install transformers tokenizers
```

### FAISS недоступен

Система автоматически использует простое хранилище. Или установите:

```bash
pip install faiss-cpu
```

## 📚 Дополнительная информация

- **Полная документация**: README.md
- **Примеры**: директория `examples/`
- **Тесты**: директория `tests/`
- **Конфигурация**: `config/default_config.yaml`

## 🚀 Дорожная карта

### v6.1 (Q1 2026)
- [ ] Потоковая передача данных в реальном времени
- [ ] Продвинутый NAS с обучением с подкреплением
- [ ] Подключение к нескольким биржам

### v6.2 (Q2 2026)
- [ ] Квантово-устойчивая криптография
- [ ] Продвинутая интерпретируемость (SHAP, LIME)
- [ ] Мобильное приложение

## 📞 Поддержка

- **Проблемы**: GitHub Issues
- **Email**: support@acts-trading.com

---

**Версия**: 6.0.0 (Полная)  
**Дата**: 2025-11-07  
**Автор**: ACTS Development Team

✨ **Удачи в трейдинге!** ✨
