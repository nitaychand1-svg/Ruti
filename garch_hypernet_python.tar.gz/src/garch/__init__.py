"""GARCH modeling components."""
