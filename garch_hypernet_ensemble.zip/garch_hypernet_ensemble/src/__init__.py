# Root package initialization
__version__ = "2.0.0"
__author__ = "AlgoTrading Team"
__license__ = "Proprietary"
